export interface calculatorAddRequest {
  intA: string;
  intB: string;
}
