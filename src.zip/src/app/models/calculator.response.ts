export class calculatorAddResponse {
  AddRespose: AddResponse;
}

interface AddResponse {
  AddResult: string;
}
